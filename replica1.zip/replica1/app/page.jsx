function Header () {
    return <h1>Words!</h1>
}

export default function main() {return (
    <div>
        <Header/>
    </div>
)}

