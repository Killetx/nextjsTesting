import Para from './para'

export default function Main() { return (<div>
    <Para/>
</div>)}