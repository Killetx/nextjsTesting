'use client'

import { useState } from 'react'


export default function Para() {
    const [paraCount, setParaCount] = useState(5)

    return <p>{"Yes " + paraCount}</p>
}